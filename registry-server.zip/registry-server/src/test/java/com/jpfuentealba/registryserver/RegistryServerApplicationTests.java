package com.jpfuentealba.registryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
