package com.jpfuentealba.reportms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
